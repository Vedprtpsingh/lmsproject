# Design: Adding C-DAC PGCP Programs Enum

**Date**: 2026-06-14  
**Status**: Approved

## Overview

Add a comprehensive `ProgramCode` enum to `Enums.java` containing all 12 C-DAC Post Graduate Certificate Programs (PGCP) currently offered by C-DAC Bangalore.

## Motivation

The LMS needs a standardized enum for C-DAC PGCP program codes to:
- Ensure consistent program code usage across the application
- Provide type safety when referencing programs
- Include human-readable display names for UI rendering
- Maintain a single source of truth for valid program codes

## Design

### Location
Add the new enum to: `lmspro-main/src/main/java/com/lms/entity/Enums.java`

### Enum Structure

```java
/**
 * C-DAC Post Graduate Certificate Program Codes
 * All PGCP programs offered by C-DAC Bangalore
 */
public enum ProgramCode {
    PGCP_AC("PGCP-AC", "Post Graduate Certificate in Advanced Computing"),
    PGCP_BDA("PGCP-BDA", "Post Graduate Certificate in Big Data Analytics"),
    PGCP_AI("PGCP-AI", "Post Graduate Certificate in Artificial Intelligence"),
    PGCP_ESD("PGCP-ESD", "Post Graduate Certificate in Embedded Systems Design"),
    PGCP_ITISS("PGCP-ITISS", "Post Graduate Certificate in IT Infrastructure, Systems & Security"),
    PGCP_VLSI("PGCP-VLSI", "Post Graduate Certificate in VLSI Design"),
    PGCP_MC("PGCP-MC", "Post Graduate Certificate in Mobile Computing"),
    PGCP_ASSD("PGCP-ASSD", "Post Graduate Certificate in Advanced Secure Software Development"),
    PGCP_RAT("PGCP-RAT", "Post Graduate Certificate in Robotics & Allied Technologies"),
    PGCP_HPCSA("PGCP-HPCSA", "Post Graduate Certificate in HPC System Administration"),
    PGCP_FBD("PGCP-FBD", "Post Graduate Certificate in FinTech & Blockchain Development"),
    PGCP_CSF("PGCP-CSF", "Post Graduate Certificate in Cyber Security & Forensics");

    private final String code;
    private final String displayName;

    ProgramCode(String code, String displayName) {
        this.code = code;
        this.displayName = displayName;
    }

    public String getCode() {
        return code;
    }

    public String getDisplayName() {
        return displayName;
    }
}
```

### Programs Included

All 12 C-DAC Bangalore PGCP programs:

1. **PGCP-AC** - Advanced Computing (ACTS)
2. **PGCP-BDA** - Big Data Analytics (ACTS)
3. **PGCP-AI** - Artificial Intelligence (AAIMS)
4. **PGCP-ESD** - Embedded Systems Design (Embedded Systems)
5. **PGCP-ITISS** - IT Infrastructure, Systems & Security (Cyber Security)
6. **PGCP-VLSI** - VLSI Design (VLSI Design)
7. **PGCP-MC** - Mobile Computing (ACTS)
8. **PGCP-ASSD** - Advanced Secure Software Development (Cyber Security)
9. **PGCP-RAT** - Robotics & Allied Technologies (ESDM)
10. **PGCP-HPCSA** - HPC System Administration (HPCE)
11. **PGCP-FBD** - FinTech & Blockchain Development (ACTS)
12. **PGCP-CSF** - Cyber Security & Forensics (Cyber Security)

### Pattern Consistency

The enum follows the existing pattern in `Enums.java`:
- Each constant has both a code value and display name
- Uses private final fields with getter methods
- Includes JavaDoc comment describing the enum's purpose
- Enum constants use underscore naming (e.g., `PGCP_AC` instead of `PGCP-AC`)

### Design Principles

1. **Single Responsibility**: The enum only manages program codes and names
2. **Immutability**: Fields are final and only expose getters
3. **Type Safety**: Using enum prevents invalid program codes
4. **Maintainability**: All program codes in one place, easy to add/modify
5. **Consistency**: Follows existing enum patterns in the codebase

## Implementation

### Files to Modify
- `lmspro-main/src/main/java/com/lms/entity/Enums.java` - Add new `ProgramCode` enum

### Placement
Add the new enum after the `Department` enum (at the end of the file, before the closing brace).

## Testing Considerations

After implementation, the enum can be used in:
- Program entity validation
- Dropdowns in frontend forms
- API request/response validation
- Database seed data

## Future Enhancements

Potential future additions (not in this implementation):
- Department mapping method (e.g., `getDepartment()` returning the associated `Department` enum)
- Course duration metadata
- Batch availability metadata
- Eligibility criteria metadata

For now, keeping it simple with just code and display name.
